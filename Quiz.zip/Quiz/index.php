<?php 

header("Location: view/index.html");?>